package edu.emory.mathcs.nlp.component.pleonastic;

import java.io.InputStream;
import java.util.List;

import edu.emory.mathcs.nlp.component.template.OnlineComponent;
import edu.emory.mathcs.nlp.component.template.eval.AccuracyEval;
import edu.emory.mathcs.nlp.component.template.eval.Eval;
import edu.emory.mathcs.nlp.component.template.node.AbstractNLPNode;

public class PleonasticClassifier<N extends AbstractNLPNode<N>> extends OnlineComponent<N, PleonasticState<N>>
{

	public PleonasticClassifier()
	{
		super(false);
	}
	
	public PleonasticClassifier(InputStream configuration)
	{
		super(false, configuration);
	}

	private static final long serialVersionUID = 4575086260746595804L;

	@Override
	protected PleonasticState<N> initState(N[] nodes)
	{
		return new PleonasticState(nodes);
	}

	@Override
	protected PleonasticState<N> initState(List<N[]> document)
	{
		return null;
	}

	@Override
	public Eval createEvaluator()
	{
		return new AccuracyEval();
	}

	@Override
	protected void postProcess(PleonasticState<N> state)
	{
		{};
	}

}
