package edu.emory.mathcs.nlp.component.pleonastic;

import java.util.Arrays;

import edu.emory.mathcs.nlp.component.template.eval.AccuracyEval;
import edu.emory.mathcs.nlp.component.template.eval.Eval;
import edu.emory.mathcs.nlp.component.template.feature.FeatureItem;
import edu.emory.mathcs.nlp.component.template.node.AbstractNLPNode;
import edu.emory.mathcs.nlp.component.template.node.NLPNode;
import edu.emory.mathcs.nlp.component.template.state.NLPState;
import edu.emory.mathcs.nlp.learning.util.LabelMap;

public class PleonasticState<N extends AbstractNLPNode<N>> extends NLPState<N>
{
	public static final String KEY = "it";
	private String[] oracle;
	private int input;
	
	public PleonasticState(N[] nodes)
	{
		super(nodes);
		input = 0;
		shift();
	}
	
	private void shift()
	{
		for(input++; input < nodes.length; input++) {
			N node = nodes[input];
			if(node.isLemma("it") && (node.getFeat("it") != null)) return;	//might need to change feature part
		}
	}

	@Override
	public boolean saveOracle()
	{
	    oracle = Arrays.stream(nodes).map(n -> n.removeFeat(KEY)).toArray(String[]::new);
	    return Arrays.stream(oracle).filter(o -> o != null).findFirst().isPresent();
	}

	@Override
	public String getOracle()
	{
		return oracle[input];
	}

	@Override
	public void resetOracle()
	{
	}

	@Override
	public void next(LabelMap map, int[] top2, float[] scores)
	{
		String label = map.getLabel(top2[0]);
		nodes[input].putFeat(KEY, label);
		shift();
	}

	@Override
	public boolean isTerminate()
	{
		return input >= nodes.length;
	}

	@Override
	public N getNode(FeatureItem item)
	{
		N node = getNode(input, item.window);
		return getRelativeNode(item, node);
	}

	@Override
	public void evaluate(Eval eval)
	{
		int correct = 0, total = 0;
		
		for(int i = 1; i < oracle.length; i++) {
			N node = nodes[i];
			String o = oracle[i];
			if(o != null && (node.getFeat("it") != null)) {
				if((((Integer.parseInt(o) > 0) && (Integer.parseInt(node.getFeat("it")) > 0)) || o.equals(node.getFeat("it")))) {
					correct++;
				}
				total++;
			}
		}
		((AccuracyEval) eval).add(correct, total);
	}
}
