# Core

The core library used for [NLP4J](https://github.com/emorynlp/nlp4j).